﻿using Microsoft.Data.SqlClient;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics.Metrics;

namespace DemoEmpApp.Models
{
    public class Employee
    {
        [Required]
        public int EmpId { get; set; }

        [Required]
        [StringLength(20)]
        [MinLength(3)]
        public string Name { get; set; }

        [Required]
        public string City { get; set; }

        [Required]
        public string Address { get; set; }


        public static List<Employee> GetAllEmployees()
        {
            List<Employee> list = new List<Employee>();
            SqlConnection cn = new SqlConnection();
           // Data Source = (localdb)\MSSQLLocalDB; Initial Catalog = master; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False
            cn.ConnectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = EmpDB; Integrated Security = True;";
            try
            {
                cn.Open();
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from EmpTable";
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    list.Add(new Employee { EmpId = (int)dr[0], Name = (string)dr[1], City = (string)dr[2], Address = (string)dr[3]});

                }
                dr.Close();
            }
            catch (Exception ex) 
            {
                throw new ExceptionClass("Exception occured in getting all employees");
            }
            finally 
            {
                cn.Close(); 
            } 
            return list;
        }
        public static void InsertEmployee(Employee emp)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = EmpDB; Integrated Security = True;";

            try
            {
                cn.Open();
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into EmpTable (Name, City, Address) values (@Name, @City, @Address)";
                cmd.Parameters.AddWithValue("@Name", emp.Name);
                cmd.Parameters.AddWithValue("@City", emp.City);
                cmd.Parameters.AddWithValue("@Address", emp.Address);

                cmd.ExecuteNonQuery();

            }
            catch(Exception ex)
            {
                throw new ExceptionClass("Exception ocurred in InsertEmployee");
            }
            finally 
            {
                cn.Close();
            }
        }
        public static Employee GetSingleEmployee(int id)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = EmpDB; Integrated Security = True;";
            try
            {
                cn.Open();
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from EmpTable where EmpId = @EmpId";
                cmd.Parameters.AddWithValue("@EmpId", id);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return new Employee { EmpId = (int)dr[0], Name = (string)dr[1], City = (string)dr[2], Address = (string)dr[3] };
                }
                else
                {
                    throw new ExceptionClass("Exception occured in Getting Employee");
                }
                dr.Close();

            }
            catch (Exception ex)
            {
                return null;
            }
            finally { cn.Close(); }

        }
        public static void UpdateEmployee(Employee emp)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = EmpDB; Integrated Security = True;";
            try
            {
                cn.Open();
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update EmpTable set Name = @Name, City = @City, Address = @Address where EmpId = @EmpId";
                cmd.Parameters.AddWithValue("@Name", emp.Name);
                cmd.Parameters.AddWithValue("@City", emp.City);
                cmd.Parameters.AddWithValue("@Address", emp.Address);
                cmd.Parameters.AddWithValue("@EmpId", emp.EmpId);
                cmd.ExecuteNonQuery();

            }
            catch(Exception ex) 
            {
                throw new ExceptionClass("Exception Occured");
            }
            finally { cn.Close(); } 
        }
        public static void DeleteEmployee(int id)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog = EmpDB; Integrated Security = True;";
            try
            {
                cn.Open();
                SqlCommand cmd = cn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from EmpTable where EmpId = @EmpId";
                cmd.Parameters.AddWithValue("@EmpId", id);
                cmd.ExecuteNonQuery();

            }
            catch
            {
                throw new ExceptionClass("Exception Occured in deleting");
            }
            finally { cn.Close(); }

        }


        public class ExceptionClass : Exception
        {
            public ExceptionClass(string msg ) : base (msg) { }
        }

        /* CREATE TABLE [dbo].[EmpTable] (
    [EmpId]   INT        IDENTITY (1, 1) NOT NULL,
    [Name]    NCHAR (10) NULL,
    [City]    NCHAR (10) NULL,
    [Address] NCHAR (10) NULL,
    PRIMARY KEY CLUSTERED ([EmpId] ASC)
);
 */
    }
}
